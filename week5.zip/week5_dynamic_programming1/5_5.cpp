#include<bits/stdc++.h>
using namespace std;
int main()
{
	int l1,l2,l3;
	cin>>l1;
	int s1[l1];
	for(int i=0;i<l1;i++)cin>>s1[i];
	cin>>l2;
	int s2[l2];
	for(int i=0;i<l2;i++)cin>>s2[i];
	cin>>l3;
	int s3[l3];
	for(int i=0;i<l3;i++)cin>>s3[i];

	int dp[l1+1][l2+1][l3+1];
	memset(dp,0,sizeof(dp));
	for(int x=1;x<=l1;x++){
		for(int y=1;y<=l2;y++){
			for(int z=1;z<=l3;z++){
			if(s1[x-1]==s2[y-1]&&s2[y-1]==s3[z-1]) dp[x][y][z]=dp[x-1][y-1][z-1]+1;
			else dp[x][y][z]=max(dp[x-1][y][z],max(dp[x][y-1][z],dp[x][y][z-1]));
			}
		}
	}
	cout<<dp[l1][l2][l3];
	}
