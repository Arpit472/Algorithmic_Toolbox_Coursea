#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[1001];
	memset(a,0,sizeof(a));
	for(int i=1;i<=1000;i++)
	{
		if(i<3) a[i]=a[i-1]+1;
		else if(i>=3 && i<4) a[i]=min((a[i-1]+1),(a[i-3]+1));
		else a[i]=min((a[i-1]+1),(min((a[i-3]+1),(a[i-4]+1))));
	}
	cout<<a[n]<<"\t";
	
}
