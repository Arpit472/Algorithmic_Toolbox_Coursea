#include<bits/stdc++.h>
using namespace std;
int main()
{
	string s1,s2;
	cin>>s1>>s2;
	int l1=s1.length();
	int l2=s2.length();
	int dp[l1+1][l2+1];
	dp[0][0]=0;
	for(int x=1;x<=l1;x++) dp[x][0]=x;
	for(int x=1;x<=l2;x++) dp[0][x]=x;
	for(int x=1;x<=l2;x++){
		for(int y=1;y<=l1;y++){
			int t1=INT_MAX,t2=INT_MAX,t3=INT_MAX;
			t1=dp[y][x-1]+1;
			t2=dp[y-1][x]+1;
			t3=(s1[y-1]==s2[x-1])? dp[y-1][x-1]:(dp[y-1][x-1]+1);
			
			dp[y][x]=min(t1,min(t2,t3));
		}
	}
	cout<<dp[l1][l2];
	}


