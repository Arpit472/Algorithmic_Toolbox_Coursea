#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[n+1];
	for(int i=0;i<=n;i++)
		a[i]=INT_MAX;
	a[0]=0;
	a[1]=0;
	for(int i=2;i<=n;i++)
	{
		int t1=INT_MAX,t2=INT_MAX,t3=INT_MAX;
		t1=a[i-1]+1;
		if(i%2==0) t2=a[i/2]+1;
		if(i%3==0) t3=a[i/3]+1;
		a[i]=min(t1,min(t2,t3)); 
	}
	cout<<a[n]<<"\n";
	stack <int> op;
	op.push(n);
	while(n>1)
	{
		if(n%3==0 && a[n]==a[n/3]+1)
		{
			op.push(n/3);
			n/=3;
		}
		else if(n%2==0 && a[n]==a[n/2]+1)
		{
			op.push(n/2);
			n/=2;
		}
		else
			{
				op.push(n-1);
				n-=1;
			}
	}
	while(!op.empty()) {cout<<op.top()<<" ";op.pop();}
}
