#include<bits/stdc++.h>
using namespace std;
int main()
{
	int l1,l2;
	cin>>l1;
	int s1[l1];
	for(int i=0;i<l1;i++)cin>>s1[i];
	cin>>l2;
	int s2[l2];
	for(int i=0;i<l2;i++)cin>>s2[i];
	int dp[l1+1][l2+1];
	dp[0][0]=0;
	for(int x=1;x<=l1;x++) dp[x][0]=0;
	for(int x=1;x<=l2;x++) dp[0][x]=0;
	for(int x=1;x<=l2;x++){
		for(int y=1;y<=l1;y++){
			int t1=0,t2=0,t3=0;
			t1=dp[y][x-1];
			t2=dp[y-1][x];
			t3=(s1[y-1]==s2[x-1])? (dp[y-1][x-1]+1):dp[y-1][x-1];
			
			dp[y][x]=max(t1,max(t2,t3));
		}
	}
	cout<<dp[l1][l2];
	}
