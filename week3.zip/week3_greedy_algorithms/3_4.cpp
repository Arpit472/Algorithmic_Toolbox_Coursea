#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;
	cin>>n;
	priority_queue<long long int> a,b;
	long long int val;
	for(int i=0;i<n;i++)
		{
			cin>>val;
			a.push(val);
		}
	for(int i=0;i<n;i++)
	{
		cin>>val;
		b.push(val);
	}
	long long int ans=0;
	while(n>0)
	{
		ans+=a.top()*b.top();
		a.pop();
		b.pop();
		n--;
	}
	cout<<ans;
}
	
