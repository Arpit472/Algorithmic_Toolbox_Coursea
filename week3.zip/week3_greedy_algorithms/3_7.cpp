#include<bits/stdc++.h>
using namespace std;
int isgreat(string x,string y)
{
    string xy=x.append(y);
	string yx=y.append(x); 
	return xy.compare(yx)>0?1:0;
}
int main()
{
	int n;
	cin>>n;
	vector <string> a;
	string help;
	for(int i=0;i<n;i++)
	{
		cin>>help;
		a.push_back(help);
	}
	sort(a.begin(),a.end(),isgreat);
	for(int x=0;x<n;x++){
		cout<<a[x];
	}
}
