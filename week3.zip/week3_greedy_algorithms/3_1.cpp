#include<iostream>
using namespace std;
int main()
{
int m;
cin>>m;
int n_c=0;
n_c+=m/10;
m%=10;
n_c+=m/5;
m%=5;
n_c+=m;
cout<<n_c;
	
}
