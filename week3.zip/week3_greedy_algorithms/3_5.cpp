#include<bits/stdc++.h>
using namespace std;
bool sortbyasc(const pair<long long int,long long int> &a,const pair<long long int,long long int> &b){
	return(a.second<b.second);
}
int main(){
	vector < pair<long long int,long long int> > seg;
	int n;
	cin>>n;
	pair<long long int,long long int> item;
	for(int x=0;x<n;x++){
		cin>>item.first>>item.second;
		seg.push_back(item);
	} 
	sort(seg.begin(),seg.end(),sortbyasc);
	int ctr=0;
	vector <long long int> p;
	for(int x=0;x<n;x++){
	   p.push_back(seg[x].second);
	   while( p[ctr]>=seg[x+1].first && x+1<n){
	   	x++;
	   }
	   ctr++;
	}
	cout<<ctr<<"\n";
	for(int x=0;x<p.size();x++){
		cout<<p[x]<<" ";
	}
	
	
}
