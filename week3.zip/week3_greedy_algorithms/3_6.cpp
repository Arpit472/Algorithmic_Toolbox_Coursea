#include<bits/stdc++.h>
using namespace std;
int main(){
	long long int n;
	cin>>n;
	long long int k=(-1+sqrt(1+8*n))/2;
	long long int d= n-(k*(k+1)/2);
	cout<<k<<"\n";
	for(int x =1;x<k;x++){
		cout<<x<<" ";
	}
	cout<<k+d;
}
