#include<bits/stdc++.h>
using namespace std;
int main()
{
	int d,m,n;
	cin>>d>>m>>n;
	int a[n+2];
	a[0]=0;
	a[n+1]=d;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	int curr=0;
	int last=0;
	int ans=0;
	while(curr<n+1)
	{
		last=curr;
		while(a[curr+1]-a[last]<=m && curr<n+1)
		{
					curr++;
		}
		
		if(last==curr)
			{
				ans=-1;
				break;
			}
		if(curr<n+1)	
		ans++;
	}
	cout<<ans;
}
