#include<bits/stdc++.h>
using namespace std;
pair<double,double> item;
int main()
{
	int n;
	double w;
	cin>>n>>w;
	double a[2][n];
	priority_queue < pair<double,int> > knap;
	for(int x=0;x<n;x++)
	{
		cin>>a[0][x]>>a[1][x];
		knap.push(make_pair((a[0][x]/a[1][x]),x));
	}
	pair <double,double> item;
	double val=0.0;
	while(w>0 && !knap.empty())
	{
	    item=knap.top();
		knap.pop();
		int index=item.second;
		double m=min(w,a[1][index]);
		
		val+=m*(a[0][index]/a[1][index]);
		w-=m;
	}
	cout<<fixed;
	cout<<setprecision(4)<<val;
		
	}
	

