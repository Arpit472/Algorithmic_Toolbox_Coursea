#include<bits/stdc++.h>
using namespace std;
int binarysearch(int a[],int n,int val)
{
	int l=0,r=n-1;
	while(l<=r)
	{
		int m=l+(r-l)/2;
		if(a[m]==val)
			return m;
		else if(a[m]<val)
			l=m+1;
		else
			r=m-1;
	}
	return -1;
}
int main()
{
	int n;
	cin>>n;
	int a[n];
	for(int i=0;i<n;i++)
		cin>>a[i];
	int k;
	cin>>k;
	int b[k];
	for(int i=0;i<k;i++)
		cin>>b[i];
	for(int i=0;i<k;i++)
	{
		cout<<binarysearch(a,n,b[i])<<" ";
	}
	
}
