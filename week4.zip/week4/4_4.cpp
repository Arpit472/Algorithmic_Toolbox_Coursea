#include<bits/stdc++.h>
using namespace std;
int ctr=0;
void merge(int a[],int l, int m, int r)
{
    int i,j,k;
    int l1=m-l+1;
    int l2=r-m;
	int lr[l1],rr[l2];
	for(int x=0;x<l1;x++)  lr[x]=a[l+x];
	for(int x=0;x<l2;x++)  rr[x]=a[m+1+x];
	i=0,k=l,j=0;
	 while (i < l1 && j < l2) { 
        if (lr[i] <= rr[j]) { 
            a[k] = lr[i++];  
        } 
        else { 
            a[k] = rr[j++]; 
			ctr+=(l1-i); 		
        } 
        k++;
    } 
   while(j<l2) a[k++]= rr[j++];
   while(i<l1) a[k++]= lr[i++];

}

void mergesort(int a[],int l,int u)
{
	if(l<u)
	{
	int mid=l+(u-l)/2;
	mergesort(a,l,mid);
	mergesort(a,mid+1,u);
     merge(a,l,mid,u);
 }
}

int main()
{
	int n;
	cin>>n;
	int a[n];
	for(int i=0;i<n;i++)
		cin>>a[i];
		
	mergesort(a,0,n-1);
	cout<<ctr;
}
