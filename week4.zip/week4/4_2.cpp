#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;
	cin>>n;
	int a[n];
	for(int x=0;x<n;x++){
		cin>>a[x];
	}
	int count=0;
	int mid=(n-1)/2;
	sort(a,a+n);
	for(int x=0;x<n;x++){
		if(a[x]==a[mid]) count++;
	}
	if(count>n/2) cout<<"1";
	else cout<<"0";
}
