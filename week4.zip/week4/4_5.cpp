#include<bits/stdc++.h>
using namespace std;
int main()
{
	int s,p;
	cin>>s>>p;
	vector <int> x;
	vector <int> y;
	vector <int>::iterator x_pt,y_pt; 
	for(int i=0;i<s;i++)
	{
		int a,b;
		cin>>a>>b;
		x.push_back(a);
		y.push_back(b);
	}
	vector <int> q;
	for(int i=0;i<p;i++)
		{
		int help;
		cin>>help;
		q.push_back(help);	
		}
	sort(x.begin(),x.end());
	sort(y.begin(),y.end());
    for(int i=0;i<p;i++){
    	x_pt=upper_bound(x.begin(),x.end(),q[i]);
    	y_pt=lower_bound(y.begin(),y.end(),q[i]);
    	int in=x_pt-x.begin();
    	int jn=y_pt-y.begin();
    //	cout<<in<<" "<<jn<<"\n";
    	cout<<in-jn<<" ";
	}

}
