#include<bits/stdc++.h>
using namespace std;
long long int m_ax[16][16],m_in[16][16];
vector <long long int> minmax(int cal[],int i,int j){
vector <long long int> arm;
arm.push_back(INT_MAX);
arm.push_back(-INT_MAX);

for(int x=i;x<j;x++){
	
long long int a,b,c,d;
	
	switch(cal[x]){
		case 1:
			a=m_ax[i][x] + m_ax[x+1][j];
			b=m_ax[i][x] + m_in[x+1][j];
			c=m_in[i][x] + m_ax[x+1][j];
			d=m_in[i][x] + m_in[x+1][j];
			break;
		case 2:
			a=m_ax[i][x] - m_ax[x+1][j];
			b=m_ax[i][x] - m_in[x+1][j];
			c=m_in[i][x] - m_ax[x+1][j];
			d=m_in[i][x] - m_in[x+1][j];
			break;
		case 3:
			a=m_ax[i][x] * m_ax[x+1][j];
			b=m_ax[i][x] * m_in[x+1][j];
			c=m_in[i][x] * m_ax[x+1][j];
			d=m_in[i][x] * m_in[x+1][j];
			break;
	}
	arm[0]=min(arm[0],min(a,min(b,min(c,d))));
	arm[1]=max(arm[1],max(a,max(b,max(c,d))));
	
}

return arm;

}

int main(){
	string s;
	cin>>s;
	int l=s.length();
	int n=(l-1)/2;
	int op[n+1];
	int cal[n];
	vector <long long int> ar;
	int op_ptr=0,calc_ptr=0;
	for(int x=0;x<l;x++){
		if(x%2==0) op[op_ptr++]=(int)(s[x]-'0');
		else {
		if(s[x]=='+') cal[calc_ptr++]=1;
		else if (s[x]=='-') cal[calc_ptr++]=2;
		else cal[calc_ptr++]=3;
	}
	}
	
	for(int x=0;x<=n;x++) {
		m_ax[x][x]=op[x];
		m_in[x][x]=op[x];
	}
	
	for(int x=1;x<=n;x++){
		for(int i=0;i<=n-x;i++){
			int j= i+x;
			ar= minmax(cal,i,j);
			m_in[i][j]=ar[0];
			m_ax[i][j]=ar[1];
		}
	}
/*	for(int x=0;x<=n;x++){
		for(int y=0;y<=n;y++)
		cout<<m_ax[x][y]<<"\t";
		cout<<"\n";
	}
		for(int x=0;x<=n;x++){
		for(int y=0;y<=n;y++)
		cout<<m_in[x][y]<<"\t";
		cout<<"\n";
	}*/
	cout<<m_ax[0][n];	
}
