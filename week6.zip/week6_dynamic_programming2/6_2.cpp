#include<bits/stdc++.h>
using namespace std;
vector <int> v;
int main(){
	int n;
	cin>>n;
	int help,sum=0;;
	bool ans=1;
	for(int x=0;x<n;x++){
	 cin>>help;
	 sum+=help;
	 v.push_back(help);
	}
	if(sum%3!=0) ans=0;
	else{
		sum/=3;
		for(int i=0;i<3;i++){
			int dp[n+1][sum+1];
			memset(dp,0,sizeof(dp));
	
			for(int x=1;x<=n;x++){
				for(int y=1;y<=sum;y++){
					int max1=0,max2=0;
					max1=dp[x-1][y];
					if(y>=v[x-1]){
					max2=dp[x-1][y-v[x-1]] + v[x-1];
					}
					dp[x][y]=max(max1,max2);
				}		
			}
			//cout<<dp[n][sum]<<"\t";
			if(dp[n][sum]!=sum) {
				ans=0;
				break;
			}
			int x=n,y=sum;
			while(y>0&&x>0){
				if(dp[x][y]==dp[x-1][y]) x--;
				else{
				
					y-=v[x-1];
				//	cout<<v[x-1]<<"\t";
					v[x-1]=0;
						x--;
				}
			}
			//cout<<"\n";
		}
		
		for(int x=0;x<n;x++){
			if(v[x]!=0) {
				ans=0;
				break;
			}
			if(x=n-1) ans=1;
		}
		
	}
	cout<<ans;
	
	
	
	
	
}
