#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,w;
	cin>>w>>n;
	int a[n];
	for(int x=0;x<n;x++) cin>>a[x];
	
	int **dp  = new int*[n+1];
	for(int x=0;x<n+1;x++){
		dp[x]=new int[w+1];
	}
//	memset(dp,0,sizeof(dp));
	
	for(int x=0;x<=n;x++){
		for(int y=0;y<=w;y++){
			if(x==0||y==0) dp[x][y]=0;
			else{
			int max1=0,max2=0;
			max1=dp[x-1][y];
			if(y>=a[x-1]){
				max2=dp[x-1][y-a[x-1]] + a[x-1];
			}
			dp[x][y]=max(max1,max2);
		}}
	}
	/*for(int x=0;x<=n;x++){
		for(int y=0;y<=w;y++) cout<<dp[x][y]<<" ";
		cout<<"\n";
	}*/
	cout<<dp[n][w];
	for(int x=0;x<n+1;x++){
		delete []dp[x];
	}
	delete []dp;
	
}
